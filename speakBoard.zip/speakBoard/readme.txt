ON WORKING PROJECT

"SpeakBoard" is software to help any person, whether child or adult, who has a certain limitation or speech disorder, to facilitate their communication to other people.
